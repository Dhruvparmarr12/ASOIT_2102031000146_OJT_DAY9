var x=5,y=6;
var z=x+y;
document.write("</br>","sum of x and y is:",z);
document.write("</br>","x is ",x);
document.write("</br>"," y is ",y);

// second program of JS
var num=100;
var str="kamlesh";
var bool=true;

document.write("</br>",typeof(num));
document.write("</br>",typeof(str));
document.write("</br>",typeof(bool));

// Third program of JS
var car = {
    modal: "BMW X3",
    color: "WHite",
    doors: 5
}
document.write("</br>"+car.modal+" "+car.color+" "+car.doors);
var cars = ["BMW","Mercedes Benz","Volkswagen"];
document.write("</br>"+cars[0]);
document.write("</br>"+cars[1]);
document.write("</br>"+cars[2]);

// fourth program of JS
let n1=30,n2=15;
var sum=n1+n2, mul=n1*n2, sub=n1-n2, div=n1/n2, mod=n1%n2;
// document.write("</br> sum:",sum+""</br> sum:",sum+""</br> sum:",sum+""</br> sum:",sum+""</br> sum:",sum+");
n1+=n2;
document.write("</br>"+n1);
let n3=30,n4=5;
n3-=n4;
document.write("</br>"+n3);
n1*=n2; 
document.write("</br>"+n1);
n1/=15;
document.write("</br>"+n1);

// "instance of" functionality
var a = ["Kamlesh", "Lohar"];
document.write("</br>",a instanceof Array);
document.write("</br>");
// // class instace of
// class Rectangle {
//     constructor(height, width) {
// this.height = height;
// this.width = width;

//     }
// }
// var R=new Rectangle(10,20);
// document.write("</br>",R instanceof Class);
 
//String OPerations
var s1="kamlesh";
var s2="Ramesh";
var s3="Suresh";
var s4="Dinesh";
document.write("</br>",s2+" "+s2);
document.write("</br>",s3+" "+s2);
document.write("</br>",s1+" "+s2);





